package var.run;

import var.practice.Practice;

public class Main {

	public static void main(String[] args) {
		// 변수 & 자료형 실습문제
		Practice test = new Practice();
		//test.실행할메소드명();
		//test.myProfile();
		//test.inputEmployee();
		//test.calculator();
		//test.printUnicode();
		test.gugudan();
		//test.rectangleCalculator();

	}

}
